# neurolab-nodejs

Command to run server.js file:

```node server.js```
